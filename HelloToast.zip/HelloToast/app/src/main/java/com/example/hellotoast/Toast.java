package com.example.hellotoast;

class Toast {
}
